import os
import gzip
import urllib.request
import pandas as pd
import numpy as np
import dask
import dask.dataframe as dd
import dask.bag as db
import pyarrow as pa
import pyarrow.parquet as pq

#DATASET_URL = "https://ndownloader.figshare.com/files/5976042"
DATASET_URL = "https://ndownloader.figshare.com/files/5976045" # for full sizepa
# link used by sklearn function fetch_kddcup99 (original link gives 403 error) for 10% dataset 
RAW_GZ_PATH   = "data/kddcup_data.gz" # compressed (.gz) dataset file
PARQUET_PATH = '/tmp/kddcup_data.parquet' # single Parquet file (ie a compressed format file but partition-able, unlike .gz) on master
PARQUET_PATH_WORKERS = '/tmp/kddcup_data.parquet'
# Local path on each worker's disk 
# has to be the same as master's, otherwise metadata issues 

# column names of KDD dataset, from source code of the above sklearn function
COL_NAMES = [
    "duration","protocol_type","service","flag","src_bytes",
    "dst_bytes","land","wrong_fragment","urgent","hot",
    "num_failed_logins","logged_in","num_compromised","root_shell",
    "su_attempted","num_root","num_file_creations","num_shells",
    "num_access_files","num_outbound_cmds","is_host_login",
    "is_guest_login","count","srv_count","serror_rate",
    "srv_serror_rate","rerror_rate","srv_rerror_rate","same_srv_rate",
    "diff_srv_rate","srv_diff_host_rate","dst_host_count",
    "dst_host_srv_count","dst_host_same_srv_rate",
    "dst_host_diff_srv_rate","dst_host_same_src_port_rate",
    "dst_host_srv_diff_host_rate","dst_host_serror_rate",
    "dst_host_srv_serror_rate","dst_host_rerror_rate",
    "dst_host_srv_rerror_rate","label"
]

# helper to count number lines in a gz file, used for partitioning later
def _count_lines_gz(filepath):
    count = 0
    with gzip.open(filepath, 'rt') as f:
        for _ in f:
            count += 1
    return count

def load_data(n_partitions=4, client=None):
    """
    1. Master downloads the .gz file, converts it to a Parquet file,
    separated into chunks of the specified size (total size / number of partitions).

    Then the Parquet dataset is converted to a distributed Dask bag of NumPy arrays. Steps:
      2. Read Parquet with Dask – workers read row groups in parallel.
      3. Preprocess: drop categorical columns, scale numeric features.
      4. Return a Dask bag where each element is a 1-D array of features.
    """
    os.makedirs("./data", exist_ok=True)

    # --- Download GZ file---
    print("Downloading compressed dataset...")
    urllib.request.urlretrieve(DATASET_URL, RAW_GZ_PATH)

    # --- Convert to Parquet---
    n_total_rows = _count_lines_gz(RAW_GZ_PATH)
    chunk_size = int(np.ceil(n_total_rows / n_partitions))
    print("Converting .gz -> Parquet chunk sizes...")
    schema = pa.schema({col: pa.string() for col in COL_NAMES})
    with gzip.open(RAW_GZ_PATH, "rt") as f_in, \
         pq.ParquetWriter(PARQUET_PATH, schema, compression='snappy') as writer:
        # pandas reads and discards chunks – never loads the whole dataset
        # (assumption: if a single worker can handle a single uncompressed partition, so can the master)
        for chunk_df in pd.read_csv(
            f_in,
            header=None,
            names=COL_NAMES,
            dtype=str,
            chunksize=chunk_size # equal to number of rows read at a time
        ):
            table = pa.Table.from_pandas(chunk_df, schema=schema)
            writer.write_table(table)
    print("Parquet file created (compressed with snappy).")

    #############################################################
    # Read the compressed Parquet file (master only)
  #  with open(PARQUET_PATH, 'rb') as f:
   #     parquet_bytes = f.read()
    
    # Copy it to every worker's disk (each worker gets its own .parquet file on disk, same path for all)
    #def save_parquet_to_workers(data):
     #   with open(PARQUET_PATH_WORKERS, 'wb') as f:
     #       f.write(data)
    #client.run(save_parquet_to_workers, parquet_bytes) # assuming already existing client
        
    #ddf = dd.read_parquet(PARQUET_PATH_WORKERS) # dask distributed dataframe, so from here on will be automatically parallelized (optimized for column operations)

load_data(n_partitions=1e3)