"""
launch_cluster.py
==================
Gestione del cluster Dask via SSH.

Pensato per essere importato da notebook:

    from launch_cluster import launch_cluster, shutdown_cluster

    cluster, client = launch_cluster(n_workers=2)
    ...
    shutdown_cluster(cluster, client)

Può anche essere lanciato standalone da terminale per tenere il cluster
vivo indipendentemente da un notebook:

    python launch_cluster.py -n 2
"""

import argparse
import time
from dask.distributed import Client, SSHCluster

# ==========================================
# CONFIGURAZIONE CENTRALIZZATA DEL CLUSTER
# ==========================================
HEAD_IP = "10.67.22.194"
WORKER_IPS = [
    "10.67.22.133",
    "10.67.22.83",
    "10.67.22.79",
    "10.67.22.106",
    "10.67.22.56",
    "10.67.22.234",
    "10.67.22.66",
    "10.67.22.32"
]
SCHEDULER_PORT = 8786
DASHBOARD_PORT = 8797
SSH_CONNECT_OPTIONS = {"known_hosts": None}
SCHEDULER_OPTIONS = {
    "port": SCHEDULER_PORT,
    "dashboard_address": f":{DASHBOARD_PORT}",
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Avvia il cluster Dask via SSH con un numero di worker configurabile."
    )
    parser.add_argument(
        "-n", "--n-workers",
        type=int,
        default=len(WORKER_IPS),
        help=f"Numero di worker da attivare, tra 1 e {len(WORKER_IPS)} "
             f"(default: tutti, {len(WORKER_IPS)}).",
    )
    return parser.parse_args()


def launch_cluster(n_workers: int, block: bool = False):
    """Avvia lo SSHCluster con i primi n_workers nodi da WORKER_IPS e si
    connette con un Client.

    Ritorna (cluster, client), così può essere chiamata ripetutamente da
    un notebook (es. dentro un ciclo che varia n_workers), chiudendo
    esplicitamente cluster/client tra un'iterazione e l'altra con
    shutdown_cluster().

    Se block=True (usato solo quando lo script è lanciato da terminale con
    `python launch_cluster.py`), resta in esecuzione finché non arriva un
    CTRL+C -- utile per tenere il cluster vivo standalone, ma NON va usato
    da notebook (bloccherebbe la cella per sempre).
    """

    if not (1 <= n_workers <= len(WORKER_IPS)):
        raise ValueError(
            f"n_workers deve essere tra 1 e {len(WORKER_IPS)} "
            f"(nodi worker disponibili), ricevuto: {n_workers}"
        )

    active_worker_ips = WORKER_IPS[:n_workers]
    # SSHCluster richiede una lista piatta: il primo elemento è lo Scheduler,
    # i successivi sono i Worker.
    ssh_hosts = [HEAD_IP] + active_worker_ips

    print(f"Inizializzazione del cluster SSH con {n_workers} worker...")
    print(f"Worker selezionati: {active_worker_ips}")

    cluster = SSHCluster(
        hosts=ssh_hosts,
        connect_options=SSH_CONNECT_OPTIONS,
        scheduler_options=SCHEDULER_OPTIONS,
    )

    client = Client(cluster)
    print("Cluster avviato e connessione stabilita con successo!\n")

    # verifica stato dei nodi
    info = client.scheduler_info()
    workers = info.get("workers", {})

    print(f"Lo Scheduler è attivo su: {client.scheduler.address}")
    print(f"Dashboard disponibile su: http://{HEAD_IP}:{DASHBOARD_PORT}")
    print(f"Il cluster ha {len(workers)} worker collegati (richiesti: {n_workers}):")

    for worker_address, worker_info in workers.items():
        mem_bytes = worker_info.get('memory_limit', 0)
        mem_gb = mem_bytes / (1024**3)
        print(f" - Worker: {worker_address} | Memoria Limite: {mem_gb:.2f} GB")

    if len(workers) != n_workers:
        print(
            f"\n[ATTENZIONE] Attesi {n_workers} worker, ma solo {len(workers)} "
            "risultano collegati. Controlla i log SSH per eventuali nodi falliti."
        )

    if block:
        print("\n[INFO] Il cluster rimarrà attivo finché questo script è in esecuzione.")
        print("Premi CTRL+C nel terminale per spegnere il cluster e terminare lo script.")
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            print("\nInterruzione rilevata. Chiusura del cluster in corso...")
            shutdown_cluster(cluster, client)

    return cluster, client


def shutdown_cluster(cluster, client):
    """Chiude ordinatamente client e cluster. Da chiamare tra un'iterazione
    e l'altra di un ciclo notebook, prima di avviare un cluster con un
    n_workers diverso, oppure a fine lavoro."""
    try:
        client.close()
    finally:
        cluster.close()
    print("Cluster e client chiusi.")


if __name__ == "__main__":
    args = parse_args()
    launch_cluster(args.n_workers, block=True)
